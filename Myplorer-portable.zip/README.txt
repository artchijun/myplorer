﻿Myplorer 0.9.37 — 파일 탐색기 + 빠른 이미지·동영상 뷰어 (Windows 10/11, 64비트)

■ 설치
  1. "20261114 1630 Myplorer v0.9.37-Setup.exe"를 더블클릭합니다.
  2. 설치할지 묻는 창에서 [확인]을 누릅니다.
  3. 설치가 끝나면 Myplorer가 바로 열립니다. 시작 메뉴와 바탕화면에 바로가기가 생깁니다.
  - 관리자 권한이 필요 없습니다. 설치 위치: %LOCALAPPDATA%\Programs\Myplorer
  - "Windows의 PC 보호" 파란 창이 뜨면 [추가 정보] → [실행]을 누릅니다.
    (코드 서명이 없는 개인 제작 프로그램이라 처음 실행할 때 나오는 경고입니다.)
  - 조용히 설치: 명령 프롬프트에서 "20261114 1630 Myplorer v0.9.37-Setup.exe" --quiet

■ 업데이트
  새 Setup 파일을 실행하면 됩니다. Myplorer가 켜져 있거나 트레이에 상주 중이면 자동으로 닫고 교체합니다.
  설정과 즐겨찾기는 그대로 유지됩니다.
  예전 이름(FlickView, FlickPlorer, 마이플로러)으로 설치했다면 새 Setup이 Myplorer로 바꿔 설치하고, 옛 프로그램 폴더와 바로가기를 지웁니다.

■ 기본 이미지 뷰어로 쓰기
  Myplorer 설정(톱니바퀴) → 시스템에서 [등록하고 Windows 설정 열기]를 누르고, Windows 설정 화면에서 Myplorer를 고릅니다.
  같은 곳에서 탐색기 우클릭 메뉴, 트레이 상주(즉시 실행), Windows 시작 시 실행도 켤 수 있습니다.

■ 제거
  Windows 설정 → 앱 → 설치된 앱 → Myplorer → 제거
  (설정, 검색 색인, 바로가기까지 모두 지웁니다.)

■ 설치 없이 쓰기 (포터블)
  "20261114 1630 Myplorer v0.9.37 포터블.zip"을 풀고 Myplorer.exe를 실행합니다.
  설정은 이 PC의 사용자 레지스트리(HKCU\Software\FlickView)에 저장됩니다.

■ 참고
  - PC 전체 검색 색인은 첫 실행 때 백그라운드에서 만들어집니다. 드라이브 크기에 따라 몇 분 걸리며, 그동안에도 사용할 수 있습니다.
  - HEIC/AVIF 사진은 Microsoft Store의 "HEIF 이미지 확장", 일부 동영상(HEVC, VP9)은 해당 코덱 확장이 필요합니다.
  - Windows N/KN 에디션은 동영상 재생에 "미디어 기능 팩"이 필요합니다.
  - 압축 해제에 miniz(MIT 라이선스)를 사용합니다. 포터블 zip의 LICENSE-miniz.txt 참고.